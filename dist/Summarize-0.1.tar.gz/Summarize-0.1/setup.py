from setuptools import setup, find_packages

setup(
    name='Summarize',
    version='0.1',
    packages=find_packages(),
    author='Maya Lekhi',
    author_email='maya.lekhi1@gmail.com',
    readme = 'README.md',
    dependencies = [
        "openai",
        "python-dotenv",
        "requests"
    ]
)
